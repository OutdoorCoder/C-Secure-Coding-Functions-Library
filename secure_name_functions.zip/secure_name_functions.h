//
// Created by Cameron on 11/8/2016.
//

#ifndef SECURE_NAME_FUNCTIONS_H
#define SECURE_NAME_FUNCTIONS_H

#include <stdio.h>
#include <regex.h>
#include <stdlib.h>
#include <memory.h>

char* getName2to50(char* firstOrLastName);
/*
 * gets a name from the user. name must be between 2 and 50 characters,
 * any non-alphabetical characters are not allowed.
 * continues until a valid input is recieved.
 * need to press enter an extra time after valid and invalid inputs.
 */

#endif //SECURE_NAME_FUNCTIONS_H
