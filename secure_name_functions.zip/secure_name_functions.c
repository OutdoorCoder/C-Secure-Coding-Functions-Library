//
// Created by Cameron on 11/8/2016.
//
#include "secure_name_functions.h"

char* getName2to50(char* firstOrLastName){
    regex_t regex;
    int reti;

    char msgbuf[100];

    char* name = (char*)malloc(sizeof(char) * 50);

    do {
        reti = regcomp(&regex, "^[A-Za-z]{2,50}\n", REG_EXTENDED);
        if (reti) {
            fprintf(stderr,"Could not compile regex\n");
            exit(1);
        }

        printf("Please enter a %s name: ", firstOrLastName);
        fgets(name, 50, stdin);

        reti = regexec(&regex, name, 0, NULL, 0);
        if (!reti) {
            printf("press enter again");
            //printf("Match");
        }
        else {
            regerror(reti, &regex, msgbuf, sizeof(msgbuf));
            fprintf(stderr,"Regex match failed: %s\n", msgbuf);
        }

        //clear input buffer
        int c;
        while ((c = getchar()) != '\n' && c != EOF);
        regfree(&regex);
        //printf("%d", reti);
    }while(reti != 0);

    //set last character to
    size_t length = strlen(name);
    if (name[length-1] == '\n')
        name[length-1] = '\0';

    return name;
    // help from source: http://stackoverflow.com/questions/1085083/regular-expressions-in-c-examples
}
