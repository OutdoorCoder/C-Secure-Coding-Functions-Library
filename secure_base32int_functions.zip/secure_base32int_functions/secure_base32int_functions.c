//
// Created by Cameron on 11/8/2016.
//

#include <stdbool.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>

int safe_add(int a, int b) {
    if (a > 0 && b > INT_MAX - a) {
        printf("Ints are too large to be added");
        exit(1);
    } else if (a < 0 && b < INT_MIN - a) {
        printf("Ints are too small to be added");
        exit(1);
    }
    return a + b;

    //source: http://codereview.stackexchange.com/questions/37177/simpler-method-to-detect-int-overflow
}

int safe_multiply(int x, int y){
    int result = 0;
    bool invalid = false;
    if (x > 0 && y > 0 && x > INT_MAX / y) invalid = true;
    if (x < 0 && y > 0 && x < INT_MIN / y) invalid = true;
    if (x > 0 && y < 0 && y < INT_MIN / x) invalid = true;
    if (x < 0 && y < 0 && (x <= INT_MIN || y <= INT_MIN || -x > INT_MAX / -y))
        invalid = true;
    if(invalid){
        printf("Values are not valid for mutliplication");
        exit(1);
    }
    result = x * y;
    return result;
    //source: http://codereview.stackexchange.com/questions/98791/safe-multiplication-of-two-64-bit-signed-integers
}