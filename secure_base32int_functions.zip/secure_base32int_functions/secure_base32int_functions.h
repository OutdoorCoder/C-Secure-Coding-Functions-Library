//
// Created by Cameron on 11/8/2016.
//

#ifndef SECURE_BASE32INT_FUNCTIONS_H
#define SECURE_BASE32INT_FUNCTIONS_H

#include <stdbool.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>

int safe_add(int a, int b);
int safe_multiply(int x, int y);

/*
 * Both methods check for integer overflow and underflow before performing
 * the operation.
 * Performs a exit(1) call if an overflow is predicted
 */

#endif //SECURE_BASE32INT_FUNCTIONS_H
