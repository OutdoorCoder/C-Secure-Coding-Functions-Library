//
// Created by Cameron on 11/8/2016.
//

#ifndef SECURE_FILE_FUNCTIONS_H
#define SECURE_FILE_FUNCTIONS_H

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <regex.h>
#include <stdbool.h>

char *get_file_name_100chars();
/*
 * gets a file name from the user that is at most 100 characters
 * changes the /n char in the input string to /0 so it can be
 * used to create a file
 */
bool file_contains_path(char *string);
/*
 * checks to see if a file name contains any / characters. Which on windows
 * may mean the user is trying to designate a specific path for the file.
 * Checks using regex
 */



bool is_txt_file(char *string);
/*
 * checks if the file ends with .txt using regex
 */


FILE *create_file_to_write(char *filename);
/*
 * creates a file that can be written too.
 * checks that the designated file is a txt file and does not contain any
 * designated path. This ensures the file is in the current directory
 */

FILE *create_file_to_read(char *filename);
/*
 * Creates a file that can be read.
 * checks that the designated file is a txt file and does not contain any
 * designated path. This ensures the file is in the current directory
 */

#endif //SECURE_FILE_FUNCTIONS_H
