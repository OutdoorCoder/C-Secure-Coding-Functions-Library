#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <regex.h>
#include <stdbool.h>

#include "./secure_file_functions.h"

char *get_file_name_100chars(){
    char *fileName = malloc(sizeof(char) * 100);

    printf("Enter a file name: ");
    fgets(fileName, 100, stdin);
    char *p = strchr(fileName, '\n'); // p will point to the newline in filename
    if(p) {
        *p = 0; // if p is not null, terminate filename at p
    }
    else{
        printf("File name is too long.");
        exit(1);
    }

    return fileName;
}

bool file_contains_path(char *string){
    regex_t regex;
    int reti;
    char msgbuf[100];

    reti = regcomp(&regex, "^[^\\/]+$", REG_EXTENDED);

    if (reti) {
        fprintf(stderr,"Could not compile regex\n");
        exit(1);
    }

    reti = regexec(&regex, string, 0, NULL, 0);
    if (!reti) {
        return false;
        //match
    }
    else {
        regerror(reti, &regex, msgbuf, sizeof(msgbuf));
        fprintf(stderr,"Regex match failed: %s\n", msgbuf);
    }
    regfree(&regex);

    return true;
}

bool is_txt_file(char *string){
    regex_t regex;
    int reti;
    char msgbuf[100];

    reti = regcomp(&regex, "^.*\\.txt$", REG_EXTENDED);

    if (reti) {
        fprintf(stderr,"Could not compile regex\n");
        exit(1);
    }

    reti = regexec(&regex, string, 0, NULL, 0);
    if (!reti) {
        return true;
        //match
    }
    else {
        regerror(reti, &regex, msgbuf, sizeof(msgbuf));
        fprintf(stderr,"Regex match failed: %s\n", msgbuf);
    }
    regfree(&regex);

    return false;
}

FILE *create_file_to_write(char *filename) {
    FILE *temp;

    /*makes sure file does not have a any path designated besides the current
    directory and that it is a txt file*/
    if (!file_contains_path(filename) && is_txt_file(filename)) {
        temp = fopen(filename, "w");
        if (temp == NULL)
        {
            printf("Error opening file!\n");
            exit(1);
        }
    }
    else{
        puts("File must be from the current directory");
        exit(1);
    }

    return temp;
}

FILE *create_file_to_read(char *filename) {
    FILE *temp;

    if (!file_contains_path(filename) && is_txt_file(filename)) {
        temp = fopen(filename, "r");
        if (!temp) {
            printf("File not found");
            exit(1);
        }
    }
    else{
        puts("File must be from the current directory");
        exit(1);
    }

    return temp;
}